-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 29-Nov-2012 às 20:38
-- Versão do servidor: 5.5.8
-- versão do PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `ifbaiano48`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `anoquestionario`
--

CREATE TABLE IF NOT EXISTS `anoquestionario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ano` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `campus`
--

CREATE TABLE IF NOT EXISTS `campus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(128) DEFAULT NULL,
  `ativo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE IF NOT EXISTS `curso` (
  `cod_curso` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(128) NOT NULL,
  `ativo` char(50) DEFAULT NULL,
  `campus` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_curso`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscrito`
--

CREATE TABLE IF NOT EXISTS `inscrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(128) NOT NULL,
  `endereco` varchar(128) NOT NULL,
  `bairro` varchar(128) NOT NULL,
  `cep` varchar(128) NOT NULL,
  `cidade` varchar(128) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `cpf` varchar(18) NOT NULL,
  `rg` varchar(11) NOT NULL,
  `especial` varchar(30) DEFAULT NULL,
  `senha` varchar(20) NOT NULL,
  `nacionalidade` varchar(128) DEFAULT NULL,
  `telefone` varchar(128) NOT NULL,
  `telefone2` varchar(128) DEFAULT NULL,
  `celular` varchar(128) DEFAULT NULL,
  `datanascimento` varchar(10) DEFAULT NULL,
  `sexo` varchar(45) DEFAULT NULL,
  `estadocivil` varchar(45) DEFAULT NULL,
  `orgaoexpedidor` varchar(45) DEFAULT NULL,
  `uf` varchar(45) DEFAULT NULL,
  `dataexpedicao` varchar(10) DEFAULT NULL,
  `especial_descricao` varchar(128) DEFAULT NULL,
  `responsavel` varchar(128) DEFAULT NULL,
  `isencao` varchar(45) DEFAULT NULL,
  `declaracao` varchar(128) DEFAULT NULL,
  `localprova` varchar(128) DEFAULT NULL,
  `numinscricao` varchar(45) NOT NULL,
  `pagamento` varchar(45) DEFAULT NULL,
  `especial_prova` varchar(10) DEFAULT NULL,
  `especial_prova_descricao` varchar(128) DEFAULT NULL,
  `vaga_especial` varchar(10) DEFAULT NULL,
  `vaga_rede_publica` varchar(10) DEFAULT NULL,
  `vaga_rural` varchar(10) DEFAULT NULL,
  `vaga_etnia` varchar(128) NOT NULL,
  `vaga_renda` varchar(128) NOT NULL,
  `campus` int(11) NOT NULL,
  `nis` varchar(15) NOT NULL,
  `curso` int(11) NOT NULL,
  `nota` decimal(3,1) unsigned DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `ultima_alteracao` date DEFAULT NULL,
  `isento_homologado` varchar(1) DEFAULT NULL,
  `mediapor1` varchar(10) DEFAULT NULL,
  `mediapor2` varchar(10) DEFAULT NULL,
  `mediapor3` varchar(10) DEFAULT NULL,
  `mediamat1` varchar(10) DEFAULT NULL,
  `mediamat2` varchar(10) DEFAULT NULL,
  `mediamat3` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `numinscricao` (`numinscricao`),
  KEY `curso` (`curso`),
  KEY `campus` (`campus`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10893 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscritoresposta`
--

CREATE TABLE IF NOT EXISTS `inscritoresposta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inscrito_id` int(11) DEFAULT NULL,
  `resposta_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inscrito_id` (`inscrito_id`),
  KEY `resposta_id` (`resposta_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=133837 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `localprova`
--

CREATE TABLE IF NOT EXISTS `localprova` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(128) DEFAULT NULL,
  `ativo` varchar(45) DEFAULT NULL,
  `campus` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `municipio`
--

CREATE TABLE IF NOT EXISTS `municipio` (
  `id` int(4) NOT NULL DEFAULT '0',
  `unidade_federativa_id` int(2) DEFAULT NULL,
  `nome` varchar(33) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unidade_federativa_municipio_fk` (`unidade_federativa_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamentos`
--

CREATE TABLE IF NOT EXISTS `pagamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_inscrito` int(11) NOT NULL,
  `arqretorno` varchar(45) DEFAULT NULL,
  `datapagamento` date DEFAULT NULL,
  `dataretorno` date DEFAULT NULL,
  `dataimportacao` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_inscrito` (`id_inscrito`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7737 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pais`
--

CREATE TABLE IF NOT EXISTS `pais` (
  `id` int(3) NOT NULL DEFAULT '0',
  `nome` varchar(26) DEFAULT NULL,
  `nacionalidade` varchar(19) DEFAULT NULL,
  `sigla` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pergunta`
--

CREATE TABLE IF NOT EXISTS `pergunta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anoquestionario_id` int(11) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `anoquestionario_id` (`anoquestionario_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `resposta`
--

CREATE TABLE IF NOT EXISTS `resposta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pergunta_id` int(11) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pergunta_id` (`pergunta_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `socioeco`
--

CREATE TABLE IF NOT EXISTS `socioeco` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inscrito_id` int(11) DEFAULT NULL,
  `respondido` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inscrito_idsocio` (`inscrito_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9623 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `unidade_federativa`
--

CREATE TABLE IF NOT EXISTS `unidade_federativa` (
  `id` int(2) NOT NULL DEFAULT '0',
  `descricao` varchar(19) DEFAULT NULL,
  `sigla` varchar(2) DEFAULT NULL,
  `pais_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pais_unidade_federativa_fk` (`pais_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_qtd_pagamentos_por_data`
--
CREATE TABLE IF NOT EXISTS `v_qtd_pagamentos_por_data` (
`datapagamento` date
,`total_pagamentos` bigint(21)
);
-- --------------------------------------------------------

--
-- Structure for view `v_qtd_pagamentos_por_data`
--
DROP TABLE IF EXISTS `v_qtd_pagamentos_por_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`ifbaiano48`@`%` SQL SECURITY DEFINER VIEW `v_qtd_pagamentos_por_data` AS select `pagamentos`.`datapagamento` AS `datapagamento`,count(`pagamentos`.`datapagamento`) AS `total_pagamentos` from `pagamentos` group by `pagamentos`.`datapagamento` order by `pagamentos`.`datapagamento`;
COMMIT;
